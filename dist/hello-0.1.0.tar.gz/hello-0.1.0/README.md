Python script to print "Hello!" with red colour.
